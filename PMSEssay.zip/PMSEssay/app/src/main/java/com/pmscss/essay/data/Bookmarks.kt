package com.pmscss.essay.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Bookmarked essay numbers, stored offline in SharedPreferences. */
class Bookmarks(context: Context) {
    private val prefs = context.getSharedPreferences("bookmarks", Context.MODE_PRIVATE)
    var ids by mutableStateOf(load())
        private set

    private fun load(): Set<Int> =
        (prefs.getStringSet("essays", emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()

    fun isBookmarked(number: Int) = number in ids

    fun toggle(number: Int) {
        ids = if (number in ids) ids - number else ids + number
        prefs.edit().putStringSet("essays", ids.map { it.toString() }.toSet()).apply()
    }
}
