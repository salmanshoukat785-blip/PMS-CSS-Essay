package com.pmscss.essay.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.Essay
import com.pmscss.essay.data.UserPrefs

@Composable
fun EssayList(essays: List<Essay>, bookmarks: Bookmarks, prefs: UserPrefs, onEssay: (Int) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(essays, key = { it.number }) { e ->
            Card(Modifier.fillMaxWidth().clickable { onEssay(e.number) }) {
                Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${e.number}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.width(44.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.title, style = MaterialTheme.typography.bodyLarge)
                        if (prefs.isRead(e.number) || prefs.notes.containsKey(e.number)) {
                            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (prefs.isRead(e.number)) {
                                    Icon(Icons.Filled.CheckCircle, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                    Text(" Read  ", style = MaterialTheme.typography.labelSmall)
                                }
                                if (prefs.notes.containsKey(e.number)) {
                                    Icon(Icons.Filled.EditNote, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                    Text(" Note", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    IconButton(onClick = { bookmarks.toggle(e.number) }) {
                        val on = bookmarks.isBookmarked(e.number)
                        Icon(if (on) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                            contentDescription = "Bookmark", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryScreen(name: String, essays: List<Essay>, bookmarks: Bookmarks, prefs: UserPrefs, onEssay: (Int) -> Unit, onBack: () -> Unit) {
    AppScaffold(title = name, onBack = onBack) { pad ->
        EssayList(essays, bookmarks, prefs, onEssay, Modifier.padding(pad))
    }
}
