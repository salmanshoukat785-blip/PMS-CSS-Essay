package com.pmscss.essay.data

import android.content.Context
import kotlinx.serialization.json.Json

/** Loads the bundled essays.json from assets (fully offline). */
object Repository {
    private val json = Json { ignoreUnknownKeys = true }
    @Volatile private var cache: EssayData? = null

    fun load(context: Context): EssayData = cache ?: synchronized(this) {
        cache ?: context.assets.open("essays.json").bufferedReader(Charsets.UTF_8).use {
            json.decodeFromString<EssayData>(it.readText())
        }.also { cache = it }
    }
}
