package com.pmscss.essay.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Category
import com.pmscss.essay.data.Essay
import com.pmscss.essay.data.UserPrefs

private val categoryIcons = listOf(
    Icons.Filled.AttachMoney, Icons.Filled.People, Icons.Filled.Warning,
    Icons.Filled.AccountBalance, Icons.Filled.HowToVote, Icons.Filled.Public,
    Icons.Filled.Eco, Icons.Filled.Memory, Icons.Filled.Security,
)

@Composable
fun HomeScreen(
    categories: List<Category>,
    prefs: UserPrefs,
    lastEssay: Essay?,
    totalEssays: Int,
    onCategory: (Int) -> Unit,
    onEssay: (Int) -> Unit,
    onSearch: () -> Unit,
    onBookmarks: () -> Unit,
    onSettings: () -> Unit,
) {
    AppScaffold(
        title = "PMS/CSS Essay",
        actions = {
            IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, contentDescription = "Search") }
            IconButton(onClick = onBookmarks) { Icon(Icons.Filled.Bookmarks, contentDescription = "Bookmarks") }
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = "Theme & settings") }
        },
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                val read = prefs.readSet.size
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Your progress: $read / $totalEssays essays read", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { if (totalEssays == 0) 0f else read.toFloat() / totalEssays },
                            modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            if (lastEssay != null) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(
                        Modifier.fillMaxWidth().clickable { onEssay(lastEssay.number) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text("Continue reading", style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer)
                                Text("Essay ${lastEssay.number}: ${lastEssay.title}", style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer)
                            }
                        }
                    }
                }
            }
            items(categories, key = { it.id }) { cat ->
                val readHere = cat.essays.count { prefs.isRead(it.number) }
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onCategory(cat.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(16.dp).heightIn(min = 140.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = CircleShape, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(categoryIcons[(cat.id - 1) % categoryIcons.size], contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(cat.name, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(Modifier.height(4.dp))
                        Text("$readHere / ${cat.essays.size} read", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
        }
    }
}
