package com.pmscss.essay.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Category

private val categoryIcons = listOf(
    Icons.Filled.AttachMoney, Icons.Filled.People, Icons.Filled.Warning,
    Icons.Filled.AccountBalance, Icons.Filled.HowToVote, Icons.Filled.Public,
    Icons.Filled.Eco, Icons.Filled.Memory, Icons.Filled.Security,
)

@Composable
fun HomeScreen(
    categories: List<Category>,
    onCategory: (Int) -> Unit,
    onSearch: () -> Unit,
    onBookmarks: () -> Unit,
) {
    AppScaffold(
        title = "PMS/CSS Essay",
        actions = {
            IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, contentDescription = "Search") }
            IconButton(onClick = onBookmarks) { Icon(Icons.Filled.Bookmarks, contentDescription = "Bookmarks") }
        },
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(categories, key = { it.id }) { cat ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onCategory(cat.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(16.dp).heightIn(min = 140.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Box(
                            Modifier.size(48.dp).clip(CircleShape)
                                .then(Modifier),
                            contentAlignment = Alignment.Center,
                        ) {
                            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = CircleShape, modifier = Modifier.fillMaxSize()) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(categoryIcons[(cat.id - 1) % categoryIcons.size], contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(cat.name, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(Modifier.height(4.dp))
                        Text("${cat.essays.size} essays", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
        }
    }
}
