package com.pmscss.essay.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Essay
import com.pmscss.essay.data.Gemini
import com.pmscss.essay.data.Generated
import com.pmscss.essay.data.UserEssays
import com.pmscss.essay.data.UserPrefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Type a topic name; Gemini writes the outline with Short and Long details and picks (or creates) a category. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEssayScreen(
    categoryNames: List<String>, prefs: UserPrefs, userEssays: UserEssays,
    onSaved: (Int) -> Unit, onSettings: () -> Unit, onBack: () -> Unit,
) {
    var topic by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<Generated?>(null) }
    var category by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val hasKey = prefs.geminiKey.isNotBlank()

    fun generate() {
        val t = topic.trim()
        if (t.length < 4 || loading) return
        scope.launch {
            loading = true; error = null; result = null
            try {
                val g = withContext(Dispatchers.IO) { Gemini.generate(prefs.geminiKey, prefs.geminiModel, t, categoryNames) }
                result = g; category = g.category
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Something went wrong. Please check your internet connection."
            }
            loading = false
        }
    }

    AppScaffold(title = "Add Essay", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Write only the topic name. Gemini AI will prepare the outline with Short and Long details in the same pattern as the other essays, and choose a category (or make a new one).",
                style = MaterialTheme.typography.bodyMedium)
            if (!hasKey) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("A Gemini API key is needed (free from aistudio.google.com/apikey). Paste it in Settings once.",
                            style = MaterialTheme.typography.bodyMedium)
                        Button(onClick = onSettings) { Text("Open Settings") }
                    }
                }
            }
            OutlinedTextField(
                value = topic, onValueChange = { topic = it.take(200) }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Essay topic") }, placeholder = { Text("e.g. Dams and Water Storage in Pakistan") },
                minLines = 2, enabled = !loading,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            )
            Button(onClick = { generate() }, enabled = hasKey && !loading && topic.trim().length >= 4, modifier = Modifier.fillMaxWidth()) {
                Text(if (result == null) "Create essay" else "Create again")
            }
            if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Writing the essay… this can take up to a minute.", style = MaterialTheme.typography.bodyMedium)
                }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }

            result?.let { g ->
                Spacer(Modifier.height(4.dp))
                Text("Preview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(topic.trim(), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(value = category, onValueChange = { category = it.take(60) }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Category (you can change it or type a new one)") }, singleLine = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    categoryNames.forEach { n -> AssistChip(onClick = { category = n }, label = { Text(n, maxLines = 1) }) }
                }
                g.sections.forEach { s ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(s.heading, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(s.short, style = MaterialTheme.typography.bodySmall)
                            s.points.forEach { Text("➢ ${it.heading}", style = MaterialTheme.typography.bodyMedium) }
                        }
                    }
                }
                Text("AI-generated: figures, years and laws may be wrong. Verify important facts before the exam. The essay will be marked as added by you with Gemini.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                Button(modifier = Modifier.fillMaxWidth(), onClick = {
                    val num = userEssays.nextNumber()
                    val date = SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date())
                    val essay = Essay(
                        number = num, title = topic.trim(), sections = g.sections,
                        source = "Added by you on $date using Google Gemini AI (${prefs.geminiModel}). AI-generated: please verify the facts before using.",
                        addedAt = System.currentTimeMillis(),
                    )
                    userEssays.add(category.trim().ifBlank { "My Essays" }, essay)
                    onSaved(num)
                }) { Text("Save essay") }
                OutlinedButton(onClick = { result = null }, modifier = Modifier.fillMaxWidth()) { Text("Discard") }
            }
        }
    }
}
