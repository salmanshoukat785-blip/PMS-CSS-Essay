package com.pmscss.essay.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Green700, onPrimary = Paper,
    primaryContainer = Green100, onPrimaryContainer = Green900,
    secondary = Gold700, onSecondary = Ink,
    secondaryContainer = Gold100, onSecondaryContainer = Ink,
    background = Paper, onBackground = Ink,
    surface = Paper, onSurface = Ink,
    surfaceVariant = Color(0xFFEAE6D8), onSurfaceVariant = Color(0xFF3F4A43),
)

private val DarkColors = darkColorScheme(
    primary = Gold500, onPrimary = Green900,
    primaryContainer = Green700, onPrimaryContainer = Gold100,
    secondary = Green500, onSecondary = Paper,
    secondaryContainer = Green900, onSecondaryContainer = Green100,
    background = NightBg, onBackground = Color(0xFFE8EDE9),
    surface = NightSurface, onSurface = Color(0xFFE8EDE9),
    surfaceVariant = Color(0xFF24312A), onSurfaceVariant = Color(0xFFC3CEC7),
)

@Composable
fun PMSEssayTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}
