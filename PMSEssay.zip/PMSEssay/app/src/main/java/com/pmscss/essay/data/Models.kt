package com.pmscss.essay.data

import kotlinx.serialization.Serializable

@Serializable
data class EssayData(val app: String = "", val categories: List<Category> = emptyList())

@Serializable
data class Category(val id: Int, val name: String, val range: List<Int>, val essays: List<Essay>)

@Serializable
data class Essay(val number: Int, val title: String, val sections: List<Section>)

/** A main heading (e.g. "1. Introduction"). Some sections only hold sub-points. */
@Serializable
data class Section(
    val heading: String,
    val short: String = "",
    val long: String = "",
    val points: List<Point> = emptyList(),
)

/** A sub-heading (➢ ...) with its own Short and Long detail. */
@Serializable
data class Point(val heading: String, val short: String = "", val long: String = "")
