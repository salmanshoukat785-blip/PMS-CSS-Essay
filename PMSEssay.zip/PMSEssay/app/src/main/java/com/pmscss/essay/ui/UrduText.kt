package com.pmscss.essay.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmscss.essay.data.Translator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Provided once from AppNav: true when Settings says essay text should open in Urdu by default. */
val LocalEssayUrdu = compositionLocalOf { false }

/** Shows the Urdu translation of [text]; fetches it online once and then reads it from the phone. */
@Composable
fun UrduText(text: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var result by remember(text) { mutableStateOf(Translator.cached(context, text)) }
    var loading by remember(text) { mutableStateOf(false) }
    var failed by remember(text) { mutableStateOf(false) }
    var attempt by remember(text) { mutableStateOf(0) }

    LaunchedEffect(text, attempt) {
        if (result != null) return@LaunchedEffect
        loading = true; failed = false
        try {
            result = withContext(Dispatchers.IO) { Translator.toUrdu(context, text) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            failed = true
        }
        loading = false
    }

    Column(modifier.fillMaxWidth()) {
        val r = result
        when {
            r != null -> {
                Text(
                    r, modifier = Modifier.fillMaxWidth(),
                    style = TextStyle(fontSize = 19.sp, lineHeight = 33.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text("Machine translation: may not be perfect.", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline)
            }
            loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Translating to Urdu…", style = MaterialTheme.typography.bodySmall)
            }
            failed -> {
                Text("Could not translate. Please check your internet connection.", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { attempt++ }) { Text("Try again") }
                VocabText(text)
            }
        }
    }
}
