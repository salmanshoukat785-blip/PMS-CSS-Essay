package com.pmscss.essay.data

import android.content.Context
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Optional online English -> Urdu translation. Each text is fetched once and then kept on the phone,
 * so translations that were already opened work offline afterwards.
 */
object Translator {
    private val json = Json { ignoreUnknownKeys = true }
    private val gate = java.util.concurrent.Semaphore(4) // many headings may be requested together

    private fun prefs(context: Context) = context.getSharedPreferences("translations", Context.MODE_PRIVATE)

    private fun key(text: String): String =
        "u_" + MessageDigest.getInstance("MD5").digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    fun cached(context: Context, text: String): String? = prefs(context).getString(key(text), null)

    /** Splits into pieces of at most ~400 characters on sentence ends, as the free services limit the request size. */
    private fun chunks(text: String): List<String> {
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (s in text.split(Regex("(?<=[.!?])\\s+"))) {
            if (cur.isNotEmpty() && cur.length + s.length + 1 > 400) { out += cur.toString(); cur = StringBuilder() }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(s)
        }
        if (cur.isNotEmpty()) out += cur.toString()
        return out
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        try {
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun viaGoogle(piece: String): String {
        val body = get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ur&dt=t&q=" +
            URLEncoder.encode(piece, "UTF-8"))
        val parts = json.parseToJsonElement(body).jsonArray[0].jsonArray
        return parts.joinToString("") { it.jsonArray[0].jsonPrimitive.content }
    }

    private fun viaMyMemory(piece: String): String {
        val body = get("https://api.mymemory.translated.net/get?q=" + URLEncoder.encode(piece, "UTF-8") + "&langpair=en%7Cur")
        val t = json.parseToJsonElement(body).jsonObject["responseData"]!!.jsonObject["translatedText"]!!.jsonPrimitive.content
        if (t.startsWith("MYMEMORY WARNING", ignoreCase = true)) throw IOException("daily limit")
        return t
    }

    /** Blocking network call: run it on Dispatchers.IO. Throws IOException when no service answers. */
    fun toUrdu(context: Context, text: String): String {
        cached(context, text)?.let { return it }
        gate.acquire()
        val result = try {
            chunks(text).joinToString(" ") { piece ->
                try { viaGoogle(piece) } catch (e: Exception) {
                    try { viaMyMemory(piece) } catch (e2: Exception) { throw IOException("Translation failed", e2) }
                }
            }
        } finally { gate.release() }
        if (result.isBlank()) throw IOException("Empty translation")
        prefs(context).edit().putString(key(text), result).apply()
        return result
    }
}
