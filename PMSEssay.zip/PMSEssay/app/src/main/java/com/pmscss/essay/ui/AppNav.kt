package com.pmscss.essay.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.EssayData
import com.pmscss.essay.data.GuideData
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.data.VocabWord
import com.pmscss.essay.data.allEssays
import com.pmscss.essay.data.findEssay
import java.util.Calendar

@Composable
fun AppNav(data: EssayData, vocab: List<VocabWord>, guide: GuideData, bookmarks: Bookmarks, prefs: UserPrefs) {
    val nav = rememberNavController()
    val all = remember(data) { data.allEssays() }
    val day = remember { val c = Calendar.getInstance(); (c.timeInMillis + c.timeZone.getOffset(c.timeInMillis)) / 86_400_000L }
    NavHost(nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen {
                nav.navigate(if (prefs.onboardingDone) "home" else "onboarding") { popUpTo("splash") { inclusive = true } }
            }
        }
        composable("onboarding") {
            OnboardingScreen {
                prefs.finishOnboarding()
                if (nav.previousBackStackEntry != null) nav.popBackStack()
                else nav.navigate("home") { popUpTo("onboarding") { inclusive = true } }
            }
        }
        composable("home") {
            HomeScreen(
                categories = data.categories, prefs = prefs,
                lastEssay = data.findEssay(prefs.lastEssay),
                wordOfDay = if (vocab.isEmpty()) null else vocab[(day % vocab.size).toInt()],
                knownCount = prefs.knownWords.size, vocabTotal = vocab.size,
                guideCount = guide.categories.size + 1,
                onCategory = { nav.navigate("category/$it") },
                onEssay = { nav.navigate("essay/$it") },
                onSearch = { nav.navigate("search") },
                onBookmarks = { nav.navigate("bookmarks") },
                onSettings = { nav.navigate("settings") },
                onVocab = { nav.navigate("vocab") },
                onProgress = { nav.navigate("progress") },
                onGuide = { nav.navigate("guide") },
            )
        }
        composable("category/{id}", listOf(navArgument("id") { type = NavType.IntType })) { entry ->
            val cat = data.categories.firstOrNull { it.id == entry.arguments?.getInt("id") }
            if (cat != null) CategoryScreen(cat.name, cat.essays, bookmarks, prefs, { nav.navigate("essay/$it") }) { nav.popBackStack() }
        }
        composable("essay/{n}", listOf(navArgument("n") { type = NavType.IntType })) { entry ->
            val essay = data.findEssay(entry.arguments?.getInt("n") ?: -1)
            if (essay != null) EssayScreen(essay, bookmarks, prefs) { nav.popBackStack() }
        }
        composable("search") { SearchScreen(data, { nav.navigate("essay/$it") }) { nav.popBackStack() } }
        composable("bookmarks") { BookmarksScreen(all, bookmarks, prefs, { nav.navigate("essay/$it") }) { nav.popBackStack() } }
        composable("vocab") { VocabScreen(vocab, prefs, { nav.navigate("essay/$it") }, { nav.navigate("flashcards") }) { nav.popBackStack() } }
        composable("flashcards") { FlashcardScreen(vocab, prefs) { nav.popBackStack() } }
        composable("progress") { ProgressScreen(data.categories, prefs, bookmarks.ids.size, all.size, vocab.size) { nav.popBackStack() } }
        composable("guide") {
            GuideScreen(guide, { nav.navigate("guide/general") }, { nav.navigate("guide/cat/$it") }) { nav.popBackStack() }
        }
        composable("guide/general") { GeneralGuideScreen(guide.general) { nav.popBackStack() } }
        composable("guide/cat/{id}", listOf(navArgument("id") { type = NavType.IntType })) { entry ->
            val g = guide.categories.firstOrNull { it.categoryId == entry.arguments?.getInt("id") }
            if (g != null) CategoryGuideScreen(g, { nav.navigate("category/${g.categoryId}") }) { nav.popBackStack() }
        }
        composable("settings") {
            SettingsScreen(prefs, { nav.navigate("userguide") }, { nav.navigate("onboarding") }, { nav.navigate("about") }) { nav.popBackStack() }
        }
        composable("userguide") { UserGuideScreen { nav.popBackStack() } }
        composable("about") {
            AboutScreen(all.size, data.categories.size, vocab.size, guide.categories.size + 1, { nav.navigate("userguide") }) { nav.popBackStack() }
        }
    }
}
