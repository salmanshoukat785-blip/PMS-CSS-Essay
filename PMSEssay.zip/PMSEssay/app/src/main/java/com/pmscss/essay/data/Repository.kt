package com.pmscss.essay.data

import android.content.Context
import kotlinx.serialization.json.Json

/** Loads the bundled JSON files from assets (fully offline). */
object Repository {
    private val json = Json { ignoreUnknownKeys = true }
    @Volatile private var cache: EssayData? = null
    @Volatile private var vocabCache: VocabData? = null

    fun load(context: Context): EssayData = cache ?: synchronized(this) {
        cache ?: context.assets.open("essays.json").bufferedReader(Charsets.UTF_8).use {
            json.decodeFromString<EssayData>(it.readText())
        }.also { cache = it }
    }

    fun loadVocab(context: Context): VocabData = vocabCache ?: synchronized(this) {
        vocabCache ?: context.assets.open("vocabulary.json").bufferedReader(Charsets.UTF_8).use {
            json.decodeFromString<VocabData>(it.readText())
        }.also { vocabCache = it }
    }
}
