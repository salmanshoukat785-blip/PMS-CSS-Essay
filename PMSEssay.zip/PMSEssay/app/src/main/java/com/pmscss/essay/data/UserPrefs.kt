package com.pmscss.essay.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

val FONT_LABELS = listOf("Small", "Normal", "Large", "Extra large")
val FONT_SCALES = listOf(0.85f, 1f, 1.15f, 1.3f)

/** Theme, font size, reading progress, last-read essay and notes. All stored offline. */
class UserPrefs(context: Context) {
    private val p = context.getSharedPreferences("user", Context.MODE_PRIVATE)

    /** 0 = system, 1 = light, 2 = dark */
    var themeMode by mutableStateOf(p.getInt("themeMode", 0)); private set
    var palette by mutableStateOf(p.getInt("palette", 0)); private set
    var fontStep by mutableStateOf(p.getInt("fontStep", 1).coerceIn(0, FONT_SCALES.lastIndex)); private set
    var lastEssay by mutableStateOf(p.getInt("lastEssay", -1)); private set
    var readSet by mutableStateOf(
        (p.getStringSet("read", emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()
    ); private set
    val notes = mutableStateMapOf<Int, String>().also { m ->
        p.all.forEach { (k, v) ->
            if (k.startsWith("note_") && v is String) k.removePrefix("note_").toIntOrNull()?.let { m[it] = v }
        }
    }

    fun setThemeMode(v: Int) { themeMode = v; p.edit().putInt("themeMode", v).apply() }
    fun setPalette(v: Int) { palette = v; p.edit().putInt("palette", v).apply() }
    fun setFontStep(v: Int) { fontStep = v; p.edit().putInt("fontStep", v).apply() }
    fun setLast(n: Int) { lastEssay = n; p.edit().putInt("lastEssay", n).apply() }

    fun isRead(n: Int) = n in readSet
    fun toggleRead(n: Int) {
        readSet = if (n in readSet) readSet - n else readSet + n
        p.edit().putStringSet("read", readSet.map { it.toString() }.toSet()).apply()
    }

    fun setNote(n: Int, text: String) {
        if (text.isBlank()) { notes.remove(n); p.edit().remove("note_$n").apply() }
        else { notes[n] = text; p.edit().putString("note_$n", text).apply() }
    }
}
