package com.pmscss.essay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Category
import com.pmscss.essay.data.Essay
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.data.VocabWord
import java.util.Calendar

internal val categoryIcons = listOf(
    Icons.Filled.AttachMoney, Icons.Filled.People, Icons.Filled.Warning,
    Icons.Filled.AccountBalance, Icons.Filled.HowToVote, Icons.Filled.Public,
    Icons.Filled.Eco, Icons.Filled.Memory, Icons.Filled.Security,
)

/** One accent colour per category, used for icon circles and progress bars. */
internal val categoryAccents = listOf(
    Color(0xFF0B5D3B), Color(0xFFB8860B), Color(0xFFB3423A),
    Color(0xFF2F6DB5), Color(0xFF6A4BA0), Color(0xFF1C8C8C),
    Color(0xFF3E8E41), Color(0xFFD0701F), Color(0xFF4A5568),
)

private val cardShape = RoundedCornerShape(20.dp)

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 12 -> "Good Morning"
        h < 17 -> "Good Afternoon"
        else -> "Good Evening"
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun QuickTile(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier.clickable(onClick = onClick), shape = cardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Surface(color = MaterialTheme.colorScheme.primary, shape = CircleShape, modifier = Modifier.size(40.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}

@Composable
private fun CategoryCard(cat: Category, prefs: UserPrefs, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val accent = categoryAccents[(cat.id - 1) % categoryAccents.size]
    val read = cat.essays.count { prefs.isRead(it.number) }
    val frac = if (cat.essays.isEmpty()) 0f else read.toFloat() / cat.essays.size
    Card(
        modifier.clickable(onClick = onClick), shape = cardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp).heightIn(min = 150.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = accent, shape = CircleShape, modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(categoryIcons[(cat.id - 1) % categoryIcons.size], contentDescription = null, tint = Color.White)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("${(frac * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = accent)
            }
            Spacer(Modifier.height(10.dp))
            Text(cat.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.weight(1f))
            Text("$read / ${cat.essays.size} read", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { frac }, modifier = Modifier.fillMaxWidth().height(6.dp),
                color = accent, trackColor = accent.copy(alpha = 0.22f),
            )
        }
    }
}

@Composable
fun HomeScreen(
    categories: List<Category>,
    prefs: UserPrefs,
    lastEssay: Essay?,
    wordOfDay: VocabWord?,
    knownCount: Int,
    vocabTotal: Int,
    guideCount: Int,
    onCategory: (Int) -> Unit,
    onEssay: (Int) -> Unit,
    onSearch: () -> Unit,
    onBookmarks: () -> Unit,
    onSettings: () -> Unit,
    onVocab: () -> Unit,
    onProgress: () -> Unit,
    onGuide: () -> Unit,
    onMock: () -> Unit,
    onQuotes: () -> Unit,
    onIdioms: () -> Unit,
) {
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = false, onClick = onSearch, icon = { Icon(Icons.Filled.Search, null) }, label = { Text("Search") })
                NavigationBarItem(selected = false, onClick = onBookmarks, icon = { Icon(Icons.Filled.Bookmarks, null) }, label = { Text("Saved") })
                NavigationBarItem(selected = false, onClick = onVocab, icon = { Icon(Icons.Filled.Translate, null) }, label = { Text("Words") })
                NavigationBarItem(selected = false, onClick = onProgress, icon = { Icon(Icons.Filled.BarChart, null) }, label = { Text("Progress") })
            }
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            // Header with greeting + search bar
            item {
                Column(
                    Modifier.fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                        .padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 22.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${greeting()} 👋", style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                            Text("PMS/CSS Essay · keep preparing for PMS 2027", style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimary)
                        }
                        IconButton(onClick = onSettings) {
                            Icon(Icons.Filled.Settings, contentDescription = "Theme & settings", tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Card(
                        Modifier.fillMaxWidth().padding(end = 8.dp).clickable(onClick = onSearch),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Search, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Text("Search essays, headings, details…", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            // Continue reading
            if (lastEssay != null) {
                item {
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { onEssay(lastEssay.number) },
                        shape = cardShape,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Continue reading", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimary)
                                Text("Essay ${lastEssay.number}: ${lastEssay.title}", style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onPrimary)
                            }
                            Icon(Icons.Filled.PlayCircle, contentDescription = "Resume", modifier = Modifier.size(40.dp),
                                tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
            }
            // Quick access
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickTile(Icons.Filled.Edit, "Writing Guide", "$guideCount step-by-step guides", onGuide, Modifier.weight(1f).fillMaxHeight())
                    QuickTile(Icons.Filled.Translate, "Vocabulary", "$knownCount / $vocabTotal words known", onVocab, Modifier.weight(1f).fillMaxHeight())
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickTile(Icons.Filled.Timer, "Mock Timer", "Practise a timed essay", onMock, Modifier.weight(1f).fillMaxHeight())
                    QuickTile(Icons.Filled.FormatQuote, "Quotes & Proverbs", "For introductions and conclusions", onQuotes, Modifier.weight(1f).fillMaxHeight())
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickTile(Icons.Filled.Lightbulb, "Idioms & Phrases", "With Urdu meanings", onIdioms, Modifier.weight(1f).fillMaxHeight())
                    Spacer(Modifier.weight(1f))
                }
            }
            // Word of the day
            if (wordOfDay != null) {
                item {
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable(onClick = onVocab),
                        shape = cardShape,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Word of the Day", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Spacer(Modifier.height(6.dp))
                            Text(wordOfDay.word, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(wordOfDay.urdu, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(wordOfDay.meaning, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
            }
            // Categories
            item { SectionHeader("Categories", "${categories.sumOf { it.essays.size }} essays in ${categories.size} categories") }
            items(categories.chunked(2), key = { it.first().id }) { pair ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { cat ->
                        CategoryCard(cat, prefs, { onCategory(cat.id) }, Modifier.weight(1f).fillMaxHeight())
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
