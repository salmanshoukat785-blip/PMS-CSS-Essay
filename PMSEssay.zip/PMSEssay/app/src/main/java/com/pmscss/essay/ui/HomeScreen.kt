package com.pmscss.essay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Category
import com.pmscss.essay.data.Essay
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.data.VocabWord
import java.util.Calendar

private val categoryIcons = listOf(
    Icons.Filled.AttachMoney, Icons.Filled.People, Icons.Filled.Warning,
    Icons.Filled.AccountBalance, Icons.Filled.HowToVote, Icons.Filled.Public,
    Icons.Filled.Eco, Icons.Filled.Memory, Icons.Filled.Security,
)

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 12 -> "Good Morning"
        h < 17 -> "Good Afternoon"
        else -> "Good Evening"
    }
}

@Composable
private fun StatTile(icon: ImageVector, value: Int, label: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(4.dp))
            Text("$value", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun CategoryCard(cat: Category, prefs: UserPrefs, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val even = cat.id % 2 == 1
    val container = if (even) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
    val onContainer = if (even) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer
    val read = cat.essays.count { prefs.isRead(it.number) }
    val frac = if (cat.essays.isEmpty()) 0f else read.toFloat() / cat.essays.size
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.fillMaxWidth().padding(14.dp).heightIn(min = 150.dp)) {
            Surface(color = MaterialTheme.colorScheme.primary, shape = CircleShape, modifier = Modifier.size(44.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(categoryIcons[(cat.id - 1) % categoryIcons.size], contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(cat.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                color = onContainer, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.weight(1f))
            Text("${cat.essays.size} essays", style = MaterialTheme.typography.bodySmall, color = onContainer)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            Text("$read / ${cat.essays.size} read", style = MaterialTheme.typography.labelSmall, color = onContainer)
        }
    }
}

@Composable
fun HomeScreen(
    categories: List<Category>,
    prefs: UserPrefs,
    lastEssay: Essay?,
    totalEssays: Int,
    bookmarkCount: Int,
    onCategory: (Int) -> Unit,
    onEssay: (Int) -> Unit,
    onSearch: () -> Unit,
    onBookmarks: () -> Unit,
    onSettings: () -> Unit,
    wordOfDay: VocabWord?,
    knownCount: Int,
    vocabTotal: Int,
    onVocab: () -> Unit,
) {
    val read = prefs.readSet.size
    val frac = if (totalEssays == 0) 0f else read.toFloat() / totalEssays
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = false, onClick = onSearch, icon = { Icon(Icons.Filled.Search, null) }, label = { Text("Search") })
                NavigationBarItem(selected = false, onClick = onBookmarks, icon = { Icon(Icons.Filled.Bookmarks, null) }, label = { Text("Saved") })
                NavigationBarItem(selected = false, onClick = onVocab, icon = { Icon(Icons.Filled.Translate, null) }, label = { Text("Words") })
                NavigationBarItem(selected = false, onClick = onSettings, icon = { Icon(Icons.Filled.Settings, null) }, label = { Text("Theme") })
            }
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad), verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 20.dp)) {
            // Header with greeting + search bar
            item {
                Column(
                    Modifier.fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                        .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 22.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${greeting()} 👋", style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                            Text("PMS/CSS Essay · keep preparing for PMS 2027", style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimary)
                        }
                        Surface(color = MaterialTheme.colorScheme.onPrimary, shape = CircleShape, modifier = Modifier.size(46.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Card(
                        Modifier.fillMaxWidth().clickable(onClick = onSearch),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Search, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Text("Search essays, headings, details…", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            // Overall progress
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(progress = { frac }, modifier = Modifier.size(84.dp), strokeWidth = 9.dp)
                            Text("${(frac * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Column(Modifier.padding(start = 18.dp)) {
                            Text("Overall Progress", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("$read of $totalEssays essays read", style = MaterialTheme.typography.bodyMedium)
                            Text(if (read == 0) "Start your first essay today!" else "Keep it up!",
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            // Stats
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(Icons.Filled.CheckCircle, read, "Read", Modifier.weight(1f))
                    StatTile(Icons.Filled.Bookmark, bookmarkCount, "Saved", Modifier.weight(1f))
                    StatTile(Icons.Filled.EditNote, prefs.notes.size, "Notes", Modifier.weight(1f))
                }
            }
            // Continue reading
            if (lastEssay != null) {
                item {
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { onEssay(lastEssay.number) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Continue reading", style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onPrimary)
                                Text("Essay ${lastEssay.number}: ${lastEssay.title}", style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onPrimary)
                            }
                            Icon(Icons.Filled.PlayCircle, contentDescription = "Resume", modifier = Modifier.size(40.dp),
                                tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
            }
            // Word of the day
            if (wordOfDay != null) {
                item {
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable(onClick = onVocab),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Translate, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                Text("  Word of the Day", style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer)
                                Spacer(Modifier.weight(1f))
                                Text("$knownCount / $vocabTotal known", style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(wordOfDay.word, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(wordOfDay.urdu, style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(wordOfDay.meaning, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
            }
            // Study streak
            item {
                val week = prefs.weekVisited()
                val days = listOf("M", "T", "W", "T", "F", "S", "S")
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp))
                            Column(Modifier.padding(start = 10.dp)) {
                                Text("Study streak", style = MaterialTheme.typography.labelMedium)
                                Text("${prefs.streak()} ${if (prefs.streak() == 1) "Day" else "Days"}",
                                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            days.forEachIndexed { i, d ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(d, style = MaterialTheme.typography.labelSmall)
                                    Spacer(Modifier.height(4.dp))
                                    Box(
                                        Modifier.size(26.dp).clip(CircleShape).background(
                                            if (week[i]) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        if (week[i]) Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.onPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Categories
            item {
                Text("Categories", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp))
            }
            items(categories.chunked(2), key = { it.first().id }) { pair ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { cat ->
                        CategoryCard(cat, prefs, { onCategory(cat.id) }, Modifier.weight(1f).fillMaxHeight())
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
