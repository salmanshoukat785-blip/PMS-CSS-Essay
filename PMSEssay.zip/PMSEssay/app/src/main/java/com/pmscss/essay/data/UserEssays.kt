package com.pmscss.essay.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class UserEssay(val category: String, val essay: Essay)

@Serializable
private data class UserEssayFile(val items: List<UserEssay> = emptyList())

/** Essays the user added with the AI option. They are kept in a private file on the phone and merged into the categories. */
class UserEssays(context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val file = File(context.filesDir, "user_essays.json")

    var items by mutableStateOf(read()); private set

    private fun read(): List<UserEssay> = try {
        if (file.exists()) json.decodeFromString<UserEssayFile>(file.readText(Charsets.UTF_8)).items else emptyList()
    } catch (e: Exception) { emptyList() }

    private fun save(list: List<UserEssay>) {
        file.writeText(json.encodeToString(UserEssayFile(list)), Charsets.UTF_8)
        items = list
    }

    /** User essay numbers start at 1001, so they never clash with the 125 bundled essays. */
    fun nextNumber(): Int = maxOf(1000, items.maxOfOrNull { it.essay.number } ?: 1000) + 1

    fun add(category: String, essay: Essay) = save(items + UserEssay(category.trim(), essay))

    fun remove(number: Int) = save(items.filter { it.essay.number != number })

    private fun norm(s: String) = s.lowercase().replace("&", "and").filter { it.isLetterOrDigit() }

    /** Adds each user essay to the bundled category with the same name, or creates a new category for it. */
    fun merge(base: EssayData): EssayData {
        if (items.isEmpty()) return base
        val extra = items.groupBy { norm(it.category) }
        val used = HashSet<String>()
        val merged = base.categories.map { c ->
            val key = norm(c.name)
            val add = extra[key]
            if (add == null) c else { used += key; c.copy(essays = c.essays + add.map { it.essay }) }
        }
        val created = extra.filterKeys { it !in used }.values.map { list ->
            val name = list.first().category
            val nums = list.map { it.essay.number }
            Category(id = 100 + (name.lowercase().hashCode() and 0x7FFFFF) % 100000, name = name,
                range = listOf(nums.min(), nums.max()), essays = list.map { it.essay }, custom = true)
        }
        return base.copy(categories = merged + created)
    }
}
