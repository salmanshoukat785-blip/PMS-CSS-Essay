package com.pmscss.essay.data

data class Hit(val essay: Essay, val label: String, val snippet: String)

fun EssayData.allEssays(): List<Essay> = categories.flatMap { it.essays }

fun EssayData.findEssay(number: Int): Essay? = allEssays().firstOrNull { it.number == number }

private fun snippetOf(text: String, index: Int): String {
    val start = maxOf(0, index - 40)
    val end = minOf(text.length, index + 90)
    return (if (start > 0) "…" else "") + text.substring(start, end) + (if (end < text.length) "…" else "")
}

/** Offline full-text search over titles, headings, short and long details. */
fun EssayData.search(query: String, perEssay: Int = 3, limit: Int = 100): List<Hit> {
    val q = query.trim().lowercase()
    if (q.length < 2) return emptyList()
    val hits = ArrayList<Hit>()
    for (essay in allEssays()) {
        var count = 0
        fun add(label: String, snippet: String) {
            if (count < perEssay && hits.size < limit) { hits.add(Hit(essay, label, snippet)); count++ }
        }
        if (essay.title.lowercase().contains(q) || q == essay.number.toString()) add("Essay ${essay.number}", "")
        for (s in essay.sections) {
            matchOf(s.heading, s.short, s.long, q)?.let { add(s.heading, it) }
            for (p in s.points) matchOf(p.heading, p.short, p.long, q)?.let { add(p.heading, it) }
        }
        if (hits.size >= limit) break
    }
    return hits
}

/** Returns a snippet if the query matches, "" if only the heading matches, null if no match. */
private fun matchOf(heading: String, short: String, long: String, q: String): String? {
    if (heading.lowercase().contains(q)) return ""
    val si = short.lowercase().indexOf(q)
    if (si >= 0) return snippetOf(short, si)
    val li = long.lowercase().indexOf(q)
    if (li >= 0) return snippetOf(long, li)
    return null
}
