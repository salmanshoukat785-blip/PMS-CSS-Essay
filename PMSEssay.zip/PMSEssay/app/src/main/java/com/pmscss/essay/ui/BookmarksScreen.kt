package com.pmscss.essay.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.Essay
import com.pmscss.essay.data.UserPrefs

@Composable
fun BookmarksScreen(all: List<Essay>, bookmarks: Bookmarks, prefs: UserPrefs, onEssay: (Int) -> Unit, onBack: () -> Unit) {
    val saved = all.filter { bookmarks.isBookmarked(it.number) }
    AppScaffold(title = "Bookmarks", onBack = onBack) { pad ->
        if (saved.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(24.dp), contentAlignment = Alignment.Center) {
                Text("No bookmarks yet. Tap the bookmark icon on any essay.")
            }
        } else {
            EssayList(saved, bookmarks, prefs, onEssay, Modifier.padding(pad))
        }
    }
}
