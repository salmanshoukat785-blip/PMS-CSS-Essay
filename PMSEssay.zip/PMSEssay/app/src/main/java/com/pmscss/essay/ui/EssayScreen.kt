package com.pmscss.essay.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.Essay

/** Short Detail is shown first; the Long Detail button expands/collapses the long text separately. */
@Composable
private fun DetailBlock(short: String, long: String) {
    var showLong by rememberSaveable { mutableStateOf(false) }
    SelectionContainer {
        Column(Modifier.fillMaxWidth()) {
            if (short.isNotBlank()) {
                Text("Short Detail", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(short, style = MaterialTheme.typography.bodyMedium)
            }
            if (long.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                FilledTonalButton(onClick = { showLong = !showLong }) {
                    Text(if (showLong) "Hide Long Detail" else "Long Detail")
                }
                AnimatedVisibility(showLong) {
                    Column {
                        Spacer(Modifier.height(8.dp))
                        Text(long, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun HeadingRow(text: String, expanded: Boolean, onClick: () -> Unit, sub: Boolean) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, modifier = Modifier.weight(1f),
            style = if (sub) MaterialTheme.typography.titleSmall else MaterialTheme.typography.titleMedium)
        Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
    }
}

@Composable
private fun PointItem(heading: String, short: String, long: String) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 2.dp)) {
            HeadingRow("➢ $heading", expanded, { expanded = !expanded }, sub = true)
            AnimatedVisibility(expanded) { Column(Modifier.padding(bottom = 12.dp)) { DetailBlock(short, long) } }
        }
    }
}

@Composable
fun EssayScreen(essay: Essay, bookmarks: Bookmarks, onBack: () -> Unit) {
    AppScaffold(
        title = "Essay ${essay.number}", onBack = onBack,
        actions = {
            IconButton(onClick = { bookmarks.toggle(essay.number) }) {
                Icon(if (bookmarks.isBookmarked(essay.number)) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    contentDescription = "Bookmark")
            }
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(essay.title, style = MaterialTheme.typography.headlineSmall) }
            items(essay.sections, key = { it.heading }) { s ->
                var expanded by rememberSaveable { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 2.dp)) {
                        HeadingRow(s.heading, expanded, { expanded = !expanded }, sub = false)
                        AnimatedVisibility(expanded) {
                            Column(Modifier.padding(bottom = 14.dp)) {
                                if (s.short.isNotBlank() || s.long.isNotBlank()) DetailBlock(s.short, s.long)
                                s.points.forEach { p -> PointItem(p.heading, p.short, p.long) }
                            }
                        }
                    }
                }
            }
        }
    }
}
