package com.pmscss.essay.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.EssayData
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.data.allEssays
import com.pmscss.essay.data.findEssay

@Composable
fun AppNav(data: EssayData, bookmarks: Bookmarks, prefs: UserPrefs) {
    val nav = rememberNavController()
    val all = remember(data) { data.allEssays() }
    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                categories = data.categories, prefs = prefs,
                lastEssay = data.findEssay(prefs.lastEssay), totalEssays = all.size,
                bookmarkCount = bookmarks.ids.size,
                onCategory = { nav.navigate("category/$it") },
                onEssay = { nav.navigate("essay/$it") },
                onSearch = { nav.navigate("search") },
                onBookmarks = { nav.navigate("bookmarks") },
                onSettings = { nav.navigate("settings") },
            )
        }
        composable("category/{id}", listOf(navArgument("id") { type = NavType.IntType })) { entry ->
            val cat = data.categories.firstOrNull { it.id == entry.arguments?.getInt("id") }
            if (cat != null) CategoryScreen(cat.name, cat.essays, bookmarks, prefs, { nav.navigate("essay/$it") }) { nav.popBackStack() }
        }
        composable("essay/{n}", listOf(navArgument("n") { type = NavType.IntType })) { entry ->
            val essay = data.findEssay(entry.arguments?.getInt("n") ?: -1)
            if (essay != null) EssayScreen(essay, bookmarks, prefs) { nav.popBackStack() }
        }
        composable("search") { SearchScreen(data, { nav.navigate("essay/$it") }) { nav.popBackStack() } }
        composable("bookmarks") { BookmarksScreen(all, bookmarks, prefs, { nav.navigate("essay/$it") }) { nav.popBackStack() } }
        composable("settings") { SettingsScreen(prefs) { nav.popBackStack() } }
    }
}
