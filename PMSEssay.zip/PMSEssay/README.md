# PMS/CSS Essay

Offline Android app (Kotlin + Jetpack Compose) with Punjab PMS 2027 essay outlines (1–125).

- Flow: Dashboard (9 categories) → Essays → Headings → Short Detail, with a "Long Detail" button.
- Data: `app/src/main/assets/essays.json` (loaded offline at startup).
- Package: `com.pmscss.essay`, minSdk 24.

## Structure
- `app/src/main/java/com/pmscss/essay/data` — models + JSON loader
- `app/src/main/java/com/pmscss/essay/ui` — screens/theme (Parts 3–5)
- `.github/workflows` — APK build (Part 6)

## Build the APK (GitHub Actions)
1. Create a new GitHub repo and push this project (steps in the chat guide).
2. Open the repo → **Actions** → **Build APK** (it runs automatically on every push; or press *Run workflow*).
3. When the run is green, open it and download **PMS-CSS-Essay-apk** from *Artifacts* (a zip containing the .apk).
4. Unzip, copy the .apk to your phone and install (allow "Install unknown apps").
