package com.pmscss.essay.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.CategoryGuide
import com.pmscss.essay.data.GeneralGuide
import com.pmscss.essay.data.GuideData
import com.pmscss.essay.data.GuideStep

private val shape = RoundedCornerShape(20.dp)

@Composable
private fun StepCard(n: Int, step: GuideStep) {
    Card(Modifier.fillMaxWidth(), shape = shape) {
        Row(Modifier.padding(14.dp)) {
            Surface(color = MaterialTheme.colorScheme.primary, shape = CircleShape, modifier = Modifier.size(34.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Text("$n", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.padding(start = 12.dp)) {
                Text(step.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(step.detail, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun BulletCard(title: String, items: List<String>) {
    if (items.isEmpty()) return
    Card(Modifier.fillMaxWidth(), shape = shape) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            items.forEach {
                Row(Modifier.padding(vertical = 3.dp)) {
                    Text("•  ", style = MaterialTheme.typography.bodyMedium)
                    Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) =
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))

/** List: the universal method plus one guide per category. */
@Composable
fun GuideScreen(guide: GuideData, onGeneral: () -> Unit, onCategory: (Int) -> Unit, onBack: () -> Unit) {
    AppScaffold(title = "Essay Writing Guide", onBack = onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(
                    Modifier.fillMaxWidth().clickable(onClick = onGeneral), shape = shape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                            Text("Universal Method", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary)
                            Text("${guide.general.steps.size} steps for any essay, with outline template, exam tips and common mistakes",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimary)
                        }
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
            item { SectionLabel("By category") }
            items(guide.categories, key = { it.categoryId }) { g ->
                Card(Modifier.fillMaxWidth().clickable { onCategory(g.categoryId) }, shape = shape) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = categoryAccents[(g.categoryId - 1) % categoryAccents.size], shape = CircleShape, modifier = Modifier.size(44.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(categoryIcons[(g.categoryId - 1) % categoryIcons.size], contentDescription = null,
                                    tint = androidx.compose.ui.graphics.Color.White)
                            }
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(g.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text("${g.steps.size} steps", style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(Icons.Filled.ChevronRight, contentDescription = null)
                    }
                }
            }
        }
    }
}

@Composable
fun GeneralGuideScreen(g: GeneralGuide, onBack: () -> Unit) {
    AppScaffold(title = "Universal Method", onBack = onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text(g.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(g.intro, style = MaterialTheme.typography.bodyMedium)
            }
            item { BulletCard("Outline template", g.outline) }
            item { SectionLabel("Step by step") }
            itemsIndexed(g.steps) { i, s -> StepCard(i + 1, s) }
            item { BulletCard("Exam tips", g.examTips) }
            item { BulletCard("Common mistakes", g.mistakes) }
        }
    }
}

@Composable
fun CategoryGuideScreen(g: CategoryGuide, onOpenEssays: () -> Unit, onBack: () -> Unit) {
    AppScaffold(title = g.name, onBack = onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("How to write ${g.name} essays", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(g.summary, style = MaterialTheme.typography.bodyMedium)
            }
            item { SectionLabel("Step by step") }
            itemsIndexed(g.steps) { i, s -> StepCard(i + 1, s) }
            item { BulletCard("Key areas to cover", g.keyAreas) }
            item { BulletCard("Pakistan context to use", g.pakistanContext) }
            if (g.thesisExample.isNotBlank()) item {
                Card(Modifier.fillMaxWidth(), shape = shape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Sample thesis statement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(Modifier.height(6.dp))
                        Text("“${g.thesisExample}”", style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
            }
            if (g.conclusionTip.isNotBlank()) item { BulletCard("Conclusion tip", listOf(g.conclusionTip)) }
            item { BulletCard("Avoid", g.avoid) }
            item { Button(onClick = onOpenEssays, modifier = Modifier.fillMaxWidth()) { Text("Open ${g.name} essays") } }
        }
    }
}
