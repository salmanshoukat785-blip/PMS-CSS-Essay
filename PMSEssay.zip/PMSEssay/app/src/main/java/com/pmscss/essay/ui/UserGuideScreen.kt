package com.pmscss.essay.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private class GuideItem(val icon: ImageVector, val title: String, val text: String)

private val guideItems = listOf(
    GuideItem(Icons.Filled.Home, "Getting started",
        "Home shows the 9 categories. Tap a category to see its essays, then tap an essay to open it. Use the bottom bar to move between Home, Search, Saved, Words and Progress."),
    GuideItem(Icons.Filled.MenuBook, "Reading an essay",
        "Tap a heading to open it. Tap a sub-heading (➢) to see its Short Detail. Press the Long Detail button for the full explanation, and press it again to hide it."),
    GuideItem(Icons.Filled.Share, "Copy and share",
        "Under every detail there are copy and share icons. The share icon at the top of an essay sends the whole outline."),
    GuideItem(Icons.Filled.Bookmark, "Bookmarks",
        "Tap the bookmark icon on an essay or in any list. All saved essays are in the Saved tab."),
    GuideItem(Icons.Filled.EditNote, "Notes",
        "Write your own note at the top of any essay. It is saved on your phone and the essay shows a Note label in lists."),
    GuideItem(Icons.Filled.CheckCircle, "Mark as read",
        "Tap the tick icon on an essay when you finish it. Your progress appears on the Home categories and in the Progress tab."),
    GuideItem(Icons.Filled.Search, "Search",
        "Search titles, headings and details from the Search tab or the search bar on Home."),
    GuideItem(Icons.Filled.Translate, "Vocabulary and flashcards",
        "Open the Words tab to browse 800+ words with Urdu meanings and examples taken from the essays. Tap a word to expand it and mark it Known or Review. Use Flashcards to practise."),
    GuideItem(Icons.Filled.Edit, "Essay Writing Guide",
        "Open the Writing Guide from Home for the Universal Method and a separate guide for each category, with steps, key areas and a sample thesis."),
    GuideItem(Icons.Filled.BarChart, "Progress and study streak",
        "The Progress tab has two tabs: Overall progress and Study streak. Open the app every day to keep your streak going."),
    GuideItem(Icons.Filled.Settings, "Theme and text size",
        "Tap the gear icon on Home to choose Light, Dark or System mode, a colour palette and the text size."),
    GuideItem(Icons.Filled.CloudOff, "Works offline",
        "Everything is stored inside the app. No internet connection or account is needed, and your bookmarks, notes and progress stay on your phone."),
)

@Composable
fun UserGuideScreen(onBack: () -> Unit) {
    AppScaffold(title = "User Guide", onBack = onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Tap a topic to learn how it works.", style = MaterialTheme.typography.bodyMedium) }
            items(guideItems, key = { it.title }) { g ->
                var open by rememberSaveable(g.title) { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth().clickable { open = !open }, shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(g.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(g.title, Modifier.weight(1f).padding(start = 12.dp), style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold)
                            Icon(if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
                        }
                        AnimatedVisibility(open) {
                            Text(g.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
            }
        }
    }
}
