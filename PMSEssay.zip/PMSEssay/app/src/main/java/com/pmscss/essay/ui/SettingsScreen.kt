package com.pmscss.essay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.FONT_LABELS
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.ui.theme.PALETTES

@Composable
private fun SectionTitle(t: String) =
    Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp, bottom = 4.dp))

@Composable
private fun OptionRow(selected: Boolean, label: String, onClick: () -> Unit, leading: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        leading()
        Text(label, Modifier.padding(start = 6.dp))
    }
}

@Composable
private fun MoreRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(label, Modifier.weight(1f).padding(start = 14.dp), style = MaterialTheme.typography.bodyLarge)
        Icon(Icons.Filled.ChevronRight, contentDescription = null)
    }
}

@Composable
fun SettingsScreen(prefs: UserPrefs, onUserGuide: () -> Unit, onIntro: () -> Unit, onAbout: () -> Unit, onBack: () -> Unit) {
    AppScaffold(title = "Settings", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            SectionTitle("Mode")
            listOf("System default", "Light", "Dark").forEachIndexed { i, l ->
                OptionRow(prefs.themeMode == i, l, { prefs.changeThemeMode(i) })
            }
            SectionTitle("Colors")
            PALETTES.forEachIndexed { i, pal ->
                OptionRow(prefs.palette == i, pal.name, { prefs.changePalette(i) }) {
                    Box(Modifier.size(22.dp).clip(CircleShape).background(pal.p))
                    Spacer(Modifier.width(4.dp))
                    Box(Modifier.size(22.dp).clip(CircleShape).background(pal.gold))
                }
            }
            SectionTitle("Text size")
            FONT_LABELS.forEachIndexed { i, l -> OptionRow(prefs.fontStep == i, l, { prefs.changeFontStep(i) }) }
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Preview", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Economic Crisis in Pakistan: Causes and Solutions", style = MaterialTheme.typography.titleMedium)
                    Text("This is how essay text will look in the app.", style = MaterialTheme.typography.bodyMedium)
                }
            }
            SectionTitle("Help & info")
            MoreRow(Icons.Filled.MenuBook, "User Guide", onUserGuide)
            MoreRow(Icons.Filled.PlayCircle, "Show intro again", onIntro)
            MoreRow(Icons.Filled.Info, "About this app", onAbout)
            Spacer(Modifier.height(16.dp))
        }
    }
}
