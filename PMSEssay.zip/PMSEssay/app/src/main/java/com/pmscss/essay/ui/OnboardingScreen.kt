package com.pmscss.essay.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private class OnbPage(val icon: ImageVector, val title: String, val text: String)

private val pages = listOf(
    OnbPage(Icons.Filled.MenuBook, "Welcome to PMS/CSS Essay",
        "125 Punjab PMS 2027 essay outlines in 9 categories, available fully offline on your phone."),
    OnbPage(Icons.Filled.TouchApp, "Read the smart way",
        "Open an essay to see its outline of headings and sub-headings. Where details are available, tap a heading for the Short Detail and press Long Detail for more."),
    OnbPage(Icons.Filled.Edit, "Learn to write",
        "Follow the step-by-step Essay Writing Guide for every category and build your vocabulary with 950+ words and flashcards."),
    OnbPage(Icons.Filled.BarChart, "Stay on track",
        "Bookmark essays, add your own notes, mark essays as read and keep your daily study streak going."),
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val state = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val last = state.currentPage == pages.lastIndex
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp)) {
        Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            if (!last) TextButton(onClick = onFinish) { Text("Skip") }
        }
        HorizontalPager(state, Modifier.weight(1f)) { i ->
            val p = pages[i]
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape, modifier = Modifier.size(128.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(p.icon, contentDescription = null, modifier = Modifier.size(60.dp), tint = MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(Modifier.height(32.dp))
                Text(p.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(p.text, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            repeat(pages.size) { i ->
                val on = i == state.currentPage
                Box(
                    Modifier.padding(4.dp).size(if (on) 12.dp else 8.dp).clip(CircleShape)
                        .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant),
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { if (last) onFinish() else scope.launch { state.animateScrollToPage(state.currentPage + 1) } },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(if (last) "Get started" else "Next") }
    }
}
