package com.pmscss.essay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.FONT_SCALES
import com.pmscss.essay.data.Repository
import com.pmscss.essay.data.UserEssays
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.ui.AppNav
import com.pmscss.essay.ui.theme.PMSEssayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = Repository.load(applicationContext) // bundled assets: works fully offline
        val vocab = Repository.loadVocab(applicationContext).vocabulary
        val guide = Repository.loadGuide(applicationContext)
        setContent {
            val prefs = remember { UserPrefs(applicationContext) }
            val bookmarks = remember { Bookmarks(applicationContext) }
            val userEssays = remember { UserEssays(applicationContext) }
            val base = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(base.density, base.fontScale * FONT_SCALES[prefs.fontStep])
            ) {
                PMSEssayTheme(prefs.themeMode, prefs.palette) {
                    Surface(Modifier.fillMaxSize()) { AppNav(data, vocab, guide, bookmarks, prefs, userEssays) }
                }
            }
        }
    }
}
