package com.pmscss.essay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.Repository
import com.pmscss.essay.ui.AppNav
import com.pmscss.essay.ui.theme.PMSEssayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = Repository.load(applicationContext) // bundled assets: works fully offline
        setContent {
            PMSEssayTheme {
                Surface(Modifier.fillMaxSize()) {
                    val bookmarks = remember { Bookmarks(applicationContext) }
                    AppNav(data, bookmarks)
                }
            }
        }
    }
}
